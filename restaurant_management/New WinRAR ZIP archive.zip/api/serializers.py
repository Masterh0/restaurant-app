from rest_framework import serializers
from main.models import Dish, Order, OrderItem, Category, CustomUser
from django.contrib.auth.hashers import make_password

class DishSerializer(serializers.ModelSerializer):
    category = serializers.PrimaryKeyRelatedField(queryset=Category.objects.all(), allow_null=False, required=True)
    image = serializers.ImageField(use_url=True, required=False)
    categoryName = serializers.CharField(source='category.name', read_only=True)

    class Meta:
        model = Dish
        fields = ['id', 'name', 'description', 'category', 'categoryName', 'price', 'image', 'created_at', 'modified_at']

    def validate_price(self, value):
        if value < 0:
            raise serializers.ValidationError('Price must be a positive number.')
        return value

    def update(self, instance, validated_data):
        image = validated_data.pop('image', None)
        if image:
            instance.image = image
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()
        return instance

class OrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Order
        fields = '__all__'

class OrderItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderItem
        fields = '__all__'

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id', 'name']

class EmployeeSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['id', 'username', 'email', 'first_name', 'last_name', 'role', 'password']
        extra_kwargs = {
            'password': {'write_only': True, 'required': False},
        }

    def validate(self, data):
        if 'new_password' in data and data['new_password']:
            data['password'] = make_password(data['new_password'])
        elif not data.get('password'):
            user = self.context['request'].user
            data['password'] = user.password
        return data

    def update(self, instance, validated_data):
        password = validated_data.pop('password', None)
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        if password:
            instance.set_password(password)
        instance.save()
        return instance

class CustomerRegistrationSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=True)
    role = serializers.CharField(default='customer', read_only=True)

    class Meta:
        model = CustomUser
        fields = ['username', 'email', 'password', 'first_name', 'last_name', 'role']
        extra_kwargs = {
            'first_name': {'required': True},
            'last_name': {'required': True},
        }

    def create(self, validated_data):
        user = CustomUser.objects.create_user(**validated_data)
        return user

class PendingOrderSerializer(serializers.ModelSerializer):
    items = OrderItemSerializer(many=True)
    total_price = serializers.ReadOnlyField()
    address = serializers.CharField(allow_blank=True, allow_null=True)

    class Meta:
        model = Order
        fields = ['id', 'status', 'total_price', 'address', 'items', 'created_at']

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        representation['total_price'] = instance.calculate_total_price
        return representation

class TopDishSerializer(serializers.ModelSerializer):
    order_count = serializers.IntegerField(source='orderitem__count', read_only=True)
    category = serializers.SerializerMethodField()
    images = serializers.SerializerMethodField()

    class Meta:
        model = Dish
        fields = ['id', 'name', 'price', 'description', 'category', 'order_count', 'images']

    def get_category(self, obj):
        return obj.category.name

    def get_images(self, obj):
        return obj.image.url if obj.image else None
