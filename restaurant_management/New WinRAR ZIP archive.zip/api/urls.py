from django.urls import path, include
from .views import DishAPIView,CategoryListAPIView,CustomAuthTokenView,EmployeeAPIView,CustomerRegistrationAPIView,CustomerDishListView,CompleteOrderAPIView,EmployeePendingOrdersView,UpdateOrderStatusView,CompletedOrderListView,TopOrderedDishesView
from . import views
urlpatterns = [
    path('dishes/', DishAPIView.as_view(), name='dish-list-create'),
    path('dishes/<int:pk>/', DishAPIView.as_view(), name='dish-detail'),
    path('categories/', CategoryListAPIView.as_view(), name='category-list'),
    path('token-auth/', CustomAuthTokenView.as_view(), name='api_token_auth'),
    path('employee/', EmployeeAPIView.as_view(), name='employee') ,
    path('employee/<int:pk>/', EmployeeAPIView.as_view(), name='employee-detail'),
    path('customer-registration/' , CustomerRegistrationAPIView.as_view(),name='customer-signup'),
    path('customer-dishes/', CustomerDishListView.as_view(), name='customer-dishes-list'),
    path('complete-order/', CompleteOrderAPIView.as_view(), name='complete-order'),
    path('orders/', EmployeePendingOrdersView.as_view(), name='employee-order-list'),
    path('orders/<int:order_id>/update-status/', UpdateOrderStatusView.as_view(), name='update-order-status'),
    path('completed-orders/', CompletedOrderListView.as_view(), name='complete-order'),
    path('top-ordered-dishes/', TopOrderedDishesView.as_view(), name='top-ordered-dishes'),






]