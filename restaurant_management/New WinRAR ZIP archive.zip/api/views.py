from rest_framework import generics
from main.models import Dish, Order, OrderItem, Category, CustomUser
from .serializers import DishSerializer, OrderSerializer, OrderItemSerializer, CategorySerializer, EmployeeSerializer, CustomerRegistrationSerializer, PendingOrderSerializer
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.mixins import ListModelMixin, CreateModelMixin, RetrieveModelMixin, UpdateModelMixin, DestroyModelMixin
from rest_framework.generics import GenericAPIView, ListAPIView
from .permissions import IsManager, IsEmployee
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.authtoken.models import Token
from django.contrib.auth.hashers import make_password
from rest_framework.filters import SearchFilter, OrderingFilter
from rest_framework.authentication import TokenAuthentication
from django.shortcuts import get_object_or_404
from django.db.models import Count    
import logging

logger = logging.getLogger(__name__)

class DishAPIView(
    GenericAPIView,
    ListModelMixin,
    CreateModelMixin,
    RetrieveModelMixin,
    UpdateModelMixin,
    DestroyModelMixin
):
    permission_classes = [IsAuthenticated, IsManager]
    queryset = Dish.objects.all().order_by('-id')
    serializer_class = DishSerializer

    def get(self, request, *args, **kwargs):
        if 'pk' in kwargs:
            return self.retrieve(request, *args, **kwargs)
        return self.list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return self.create(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        instance = self.get_object()
        if 'image' not in request.data:
            request.data._mutable = True
            request.data['image'] = instance.image.name
        return self.update(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        return self.destroy(request, *args, **kwargs)

class CategoryListAPIView(ListAPIView):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer

class CustomAuthTokenView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = [TokenAuthentication]

    def post(self, request, *args, **kwargs):
        username = request.data.get('username')
        password = request.data.get('password')
        if not username or not password:
            return Response({"error": "Both username and password are required."}, status=status.HTTP_400_BAD_REQUEST)
        user = CustomUser.objects.filter(username=username).first()
        if user and user.check_password(password):
            token, created = Token.objects.get_or_create(user=user)
            return Response({
                "token": token.key,
                "user_id": user.id,
                "username": user.username,
                "role": user.role
            }, status=status.HTTP_200_OK)
        return Response({"error": "Invalid credentials."}, status=status.HTTP_401_UNAUTHORIZED)

class EmployeeAPIView(
    GenericAPIView,
    ListModelMixin,
    CreateModelMixin,
    RetrieveModelMixin,
    UpdateModelMixin,
    DestroyModelMixin
):
    permission_classes = [IsAuthenticated, IsManager]
    queryset = CustomUser.objects.filter(role="employee").order_by("-id")
    serializer_class = EmployeeSerializer

    def get(self, request, *args, **kwargs):
        if "pk" in kwargs:
            return self.retrieve(request, *args, **kwargs)
        return self.list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        data = request.data.copy()
        if "role" not in data or data["role"] == "":
            data["role"] = "employee"
        if "password" in data and data["password"]:
            data["password"] = make_password(data["password"])
        serializer = EmployeeSerializer(data=data)
        if serializer.is_valid():
            user=serializer.save()
            token, created = Token.objects.get_or_create(user=user)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, *args, **kwargs):
        instance = self.get_object()
        data = request.data
        logger.debug("Received data for updating employee.")
        if "new_password" in data and data["new_password"]:
            data["password"] = make_password(data["new_password"])
        else:
            data["password"] = instance.password
        serializer = self.get_serializer(instance, data=data, partial=True)
        if serializer.is_valid():
            serializer.save()
            logger.debug(f"Employee updated successfully: {serializer.data}")
            return Response(serializer.data, status=status.HTTP_200_OK)
        logger.error(f"Serializer validation failed: {serializer.errors}")
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, *args, **kwargs):
        return self.destroy(request, *args, **kwargs)

class CustomerRegistrationAPIView(APIView):
    permission_classes = [AllowAny]

    def post(self, request, *args, **kwargs):
        serializer = CustomerRegistrationSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save(role='customer')
            token, created = Token.objects.get_or_create(user=user)
            return Response({
                'message': 'Customer registration successful!',
                'user': serializer.data,
                'token': token.key
            }, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class CustomerDishListView(generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    queryset = Dish.objects.all()
    serializer_class = DishSerializer
    filter_backends = [SearchFilter, OrderingFilter]
    filterset_fields = ['category__name']
    search_fields = ['category__name']

    def get_queryset(self):
        queryset = super().get_queryset()
        category_name = self.request.query_params.get('category', None)
        if category_name and category_name != 'All':
            queryset = queryset.filter(category__name=category_name)
        return queryset

class CompleteOrderAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, *args, **kwargs):
        user = request.user
        address = request.data.get('address')
        items = request.data.get('items', [])
        if not items:
            return Response({"error": "No items provided"}, status=status.HTTP_400_BAD_REQUEST)
        total_price = 0
        order = Order.objects.create(user=user, address=address)
        for item in items:
            dish = Dish.objects.get(id=item['id'])
            quantity = item['quantity']
            price = dish.price * quantity
            total_price += price
            OrderItem.objects.create(order=order, dish=dish, quantity=quantity)
        order.total_price = total_price
        order.save()
        return Response({"message": "Order completed successfully", "total_price": total_price})

class EmployeePendingOrdersView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        pending_orders = Order.objects.filter(status='pending')
        serializer = PendingOrderSerializer(pending_orders, many=True)
        return Response(serializer.data)

    def patch(self, request, pk):
        order = Order.objects.get(pk=pk, status='pending')
        order.status = 'completed'
        order.save()
        return Response({'status': 'Order status updated to completed'}, status=status.HTTP_200_OK)

class UpdateOrderStatusView(generics.UpdateAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = PendingOrderSerializer

    def get_queryset(self):
        user = self.request.user
        return Order.objects.filter(user=user, status='pending')

    def patch(self, request, order_id):
        order = get_object_or_404(Order, id=order_id)
        status_update = request.data.get('status')
        if status_update not in ['completed', 'canceled']:
            return Response({"error": "Invalid status"}, status=status.HTTP_400_BAD_REQUEST)
        order.status = status_update
        order.save()
        return Response({"message": "Order status updated successfully"}, status=status.HTTP_200_OK)

class CompletedOrderListView(APIView):
    permission_classes = [IsAuthenticated,IsEmployee]

    def get(self, request, format=None):
        completed_orders = Order.objects.filter(status='completed')
        serializer = PendingOrderSerializer(completed_orders, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
class TopOrderedDishesView(APIView):
    def get(self, request):
        top_dishes = (
            OrderItem.objects
            .values('dish__id', 'dish__name', 'dish__price')
            .annotate(order_count=Count('id'))
            .order_by('-order_count')[:5]
        )
        dish_ids = [dish['dish__id'] for dish in top_dishes]
        detailed_dishes = Dish.objects.filter(id__in=dish_ids)
        serializer = DishSerializer(detailed_dishes, many=True)
        return Response({
            'top_dishes': serializer.data
        }, status=status.HTTP_200_OK)
